<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{ $subject ?? ($notification->title ?? config('app.name').' Notification') }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f5f7;
            margin: 0;
            padding: 0;
        }
        .container {
            background-color: #ffffff;
            max-width: 520px;
            margin: 30px auto;
            padding: 28px 30px 32px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(15, 23, 42, 0.08);
        }
        .logo {
            text-align: center;
            font-weight: 700;
            font-size: 22px;
            letter-spacing: 0.06em;
            color: #0d6efd;
            margin-bottom: 6px;
            text-transform: uppercase;
        }
        .tagline {
            text-align: center;
            font-size: 13px;
            color: #6b7280;
            margin-bottom: 20px;
        }
        h2 {
            color: #111827;
            font-size: 22px;
            margin: 12px 0 6px;
            text-align: left;
        }
        .meta {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.12em;
            color: #9ca3af;
        }
        p {
            color: #4b5563;
            font-size: 15px;
            line-height: 1.6;
            margin: 10px 0;
        }
        .highlight-box {
            background: linear-gradient(135deg, #eff6ff, #ecfdf5);
            border-radius: 10px;
            padding: 14px 16px;
            margin: 16px 0 6px;
            border: 1px solid #dbeafe;
        }
        .highlight-title {
            font-weight: 600;
            font-size: 14px;
            color: #1d4ed8;
            margin-bottom: 4px;
        }
        .highlight-text {
            font-size: 14px;
            color: #111827;
        }
        .button {
            display: inline-block;
            background: linear-gradient(135deg, #0d6efd, #2563eb);
            color: #ffffff !important;
            text-decoration: none;
            padding: 11px 26px;
            border-radius: 999px;
            font-weight: 600;
            font-size: 14px;
            margin-top: 18px;
        }
        .support {
            margin-top: 24px;
            font-size: 13px;
            color: #6b7280;
        }
        .footer {
            font-size: 12px;
            color: #9ca3af;
            text-align: center;
            margin-top: 24px;
        }
        .footer a {
            color: #6b7280;
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="logo">{{ config('app.name') }}</div>
    <div class="tagline">Smart community platform for businesses, jobs, matrimony & more</div>

    @if(!empty($greeting))
        <p>{{ $greeting }}</p>
    @else
        <p>Hi {{ $userName ?? ($notification->user->name ?? 'there') }},</p>
    @endif

    <div class="meta">{{ strtoupper($notification->type ?? 'Notification') }}</div>
    <h2>{{ $notification->title ?? ($subject ?? 'You have a new update') }}</h2>

    <div class="highlight-box">
        <div class="highlight-title">What happened?</div>
        <div class="highlight-text">
            {{ $notification->message ?? $message ?? 'There is a new activity on your account.' }}
        </div>
    </div>

    @if(!empty($actionUrl))
        <p style="text-align: center;">
            <a href="{{ $actionUrl }}" class="button">
                {{ $actionLabel ?? 'View details' }}
            </a>
        </p>
    @elseif(!empty($notification->action_url))
        <p style="text-align: center;">
            <a href="{{ $notification->action_url }}" class="button">
                {{ $actionLabel ?? 'Open in '.config('app.name') }}
            </a>
        </p>
    @endif

    @if(!empty($extraLines) && is_array($extraLines))
        @foreach($extraLines as $line)
            <p>{{ $line }}</p>
        @endforeach
    @endif

    <p class="support">
        If you didn’t expect this email or think something is wrong, please contact our support team.
    </p>

    <div class="footer">
        &copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.<br>
        This is an automated message sent to {{ $notification->user->email ?? '' }}.
    </div>
</div>
</body>
</html>


